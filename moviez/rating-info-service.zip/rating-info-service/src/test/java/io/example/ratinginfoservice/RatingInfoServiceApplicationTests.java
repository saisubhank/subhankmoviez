package io.example.ratinginfoservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RatingInfoServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
